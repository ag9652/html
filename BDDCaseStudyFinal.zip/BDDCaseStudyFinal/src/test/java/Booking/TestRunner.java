package Booking;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"},features= {"C:\\Users\\goallu\\Desktop\\BDDCaseStudyFinal\\src\\test\\resources\\Booking\\Booking.feature"}) public class TestRunner {

}