import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-search-employee',
  templateUrl: './search-employee.component.html',
  styleUrls: ['./search-employee.component.css']
})
export class SearchEmployeeComponent implements OnInit {
  employeeser:MyServiceService;
  emp:Employee[];
  constructor(employeeser:MyServiceService) { 
  this.employeeser=employeeser;
  }
  search(data){
    this.emp=this.employeeser.searchData(data);
  }
  ngOnInit() {
  }

}
