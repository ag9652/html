import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menclothes',
  templateUrl: './menclothes.component.html',
  styleUrls: ['./menclothes.component.css']
})
export class MenclothesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
