import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WomenwatchesComponent } from './womenwatches.component';

describe('WomenwatchesComponent', () => {
  let component: WomenwatchesComponent;
  let fixture: ComponentFixture<WomenwatchesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WomenwatchesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WomenwatchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
