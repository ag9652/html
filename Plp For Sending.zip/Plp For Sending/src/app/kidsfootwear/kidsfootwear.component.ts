import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kidsfootwear',
  templateUrl: './kidsfootwear.component.html',
  styleUrls: ['./kidsfootwear.component.css']
})
export class KidsfootwearComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
