import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managing-merchant',
  templateUrl: './managing-merchant.component.html',
  styleUrls: ['./managing-merchant.component.css']
})
export class ManagingMerchantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
