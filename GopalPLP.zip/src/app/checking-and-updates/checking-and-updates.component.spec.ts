import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckingAndUpdatesComponent } from './checking-and-updates.component';

describe('CheckingAndUpdatesComponent', () => {
  let component: CheckingAndUpdatesComponent;
  let fixture: ComponentFixture<CheckingAndUpdatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckingAndUpdatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckingAndUpdatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
