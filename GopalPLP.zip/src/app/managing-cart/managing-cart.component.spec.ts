import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagingCartComponent } from './managing-cart.component';

describe('ManagingCartComponent', () => {
  let component: ManagingCartComponent;
  let fixture: ComponentFixture<ManagingCartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagingCartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagingCartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
