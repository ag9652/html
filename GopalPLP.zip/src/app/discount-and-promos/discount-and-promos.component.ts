import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discount-and-promos',
  templateUrl: './discount-and-promos.component.html',
  styleUrls: ['./discount-and-promos.component.css']
})
export class DiscountAndPromosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
