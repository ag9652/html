import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managing-inventory',
  templateUrl: './managing-inventory.component.html',
  styleUrls: ['./managing-inventory.component.css']
})
export class ManagingInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
