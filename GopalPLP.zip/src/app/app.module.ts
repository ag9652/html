import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ManagingInventoryComponent } from './managing-inventory/managing-inventory.component';
import { ManagingMerchantComponent } from './managing-merchant/managing-merchant.component';
import { ManagingThirdPartyMerchantComponent } from './managing-third-party-merchant/managing-third-party-merchant.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { DiscountAndPromosComponent } from './discount-and-promos/discount-and-promos.component';
import { SearchComponent } from './search/search.component';
import { ManagingCartComponent } from './managing-cart/managing-cart.component';
import { CheckingAndUpdatesComponent } from './checking-and-updates/checking-and-updates.component';

@NgModule({
  declarations: [
    AppComponent,
    ManagingInventoryComponent,
    ManagingMerchantComponent,
    ManagingThirdPartyMerchantComponent,
    FeedbackComponent,
    DiscountAndPromosComponent,
    SearchComponent,
    ManagingCartComponent,
    CheckingAndUpdatesComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
