import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-emp',
  templateUrl: './update-emp.component.html',
  styleUrls: ['./update-emp.component.css']
})
export class UPdateEmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  

}
